#!/bin/bash
tprfile=$1
outprefix=$2
time_in_ns=$3
gmxexe=$4

if [ -z "$time_in_ns" ];then
echo "Usage: $0 tprfile outprefix time_in_ns (gmxexe)"
exit
fi

if [ -z "$gmxexe" ];then
    module load cuda/7.5
    source /project/gavoth/glen842/software/gromacs-5.1.2_plumedpinioncleanup/bin/GMXRC.bash
    gmxexe=gmx_plumed
fi

timestep=2 #fs
steps=$(echo $time_in_ns*1000000/$timestep |bc)
outdir=$(dirname $outprefix)
mkdir -p $outdir

progressfile=$outprefix.progress.txt
# next line returns 0 even if file not found
prevsteps=$(echo $(cat $progressfile). *1|bc) 
newsteps=$(($prevsteps+$steps))
outprefix_old=${outprefix}.run.$prevsteps
outprefix_new=${outprefix}.run.$newsteps

if [ "$prevsteps" -gt 0 ];then
    continuestring="-cpi $outprefix_old.cpt"
else
    continuestring=""
fi

mpirun $gmxexe mdrun -ntomp 1 -s $tprfile $continuestring -deffnm $outprefix_new -nsteps $steps $plumedstring # 2>&1 > $outprefix_new.stdout.log 

outgro=$outprefix_new.gro
sleep 1
if [ -e "$outgro" ];then
    echo $newsteps > $progressfile
fi
