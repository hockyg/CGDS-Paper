#!/usr/bin/python
import sys
import numpy as np
import matplotlib as mpl
mpl.use('Qt4Agg')
import pylab

data_file = sys.argv[1]
col = int(sys.argv[2])-1

data = np.loadtxt(data_file)
data = data[len(data)//2:,col]

#kt in kj/mol
KbT=2.479
avg_val = data.mean()
#avg2_val = (data*data).mean()


std_val = data.std()
#print "#",avg_val, avg2_val,std_val
step=0.02

#def first_order_est(target_val):
#    return KbT*(target_val-avg_val)/(2*avg_val*target_val-target_val*target_val-avg2_val)

def est_zero_mean(data,target_val):
     df = (data-target_val)
     f1 = df.mean()
     f2 = (df*df).mean()
     f3 = (df*df*df).mean()
     f4 = (df*df*df*df).mean()
     f5 = (df*df*df*df*df).mean()
     f6 = (df*df*df*df*df*df).mean()
     print "#",f1,f2,f3,f4,f5,f6

     est1 = f1/f2
     est2a = ( (f2-np.sqrt(f2*f2-2*f1*f3))/f3 )
     est2b = ( (f2+np.sqrt(f2*f2-2*f1*f3))/f3 )

     return est1,"|",est2a,est2b,"|"

for target_val in np.arange(avg_val-std_val*4,avg_val+std_val*4+step/2.,step):
    print target_val, est_zero_mean(data,target_val)
print "# exact"
print avg_val, est_zero_mean(data,avg_val)
print "# exact+0.1sig"
print avg_val, est_zero_mean(data,avg_val+std_val*0.1)
