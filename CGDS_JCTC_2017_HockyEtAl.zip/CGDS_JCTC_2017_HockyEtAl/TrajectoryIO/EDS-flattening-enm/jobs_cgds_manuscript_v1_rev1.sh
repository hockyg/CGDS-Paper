bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr no-eds/no-eds.plumed.dat 50 200

#for frequent calc
bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr no-eds/no-eds.plumed.dat 0.5 50

bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr us-flatten-dihed-mean/flatten_us_k500.plumed.dat 50 200
bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr us-flatten-dihed-mean/flatten_us_k5000.plumed.dat 50 200
bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr us-flatten-dihed-mean/flatten_us_k1000.plumed.dat 50 200
bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr us-flatten-dihed-mean/flatten_us_k10000.plumed.dat 50 200


bash run_scan_tau.sh
bash run_scan_target.sh
#do this one twice
bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-mean2-cleft-mean-mean2/sgd/flatten_4cv.range10_init0.plumed.dat 10 200

bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-mean2-cleft-mean-mean2/simul/flatten_4cv.range10_init0.plumed.dat 10 200
bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-mean2-cleft-mean-mean2/simul/flatten_4cv.range1_init0.plumed.dat 10 200

bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-mean2-cleft-mean-mean2/lm_fixed/flatten_4cv.range1_init0_lm01.plumed.dat 10 200
bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-mean2-cleft-mean-mean2/lm_fixed/flatten_4cv.range1_init0_lm001.plumed.dat 10 200
bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-mean2-cleft-mean-mean2/lm_adaptive/flatten_4cv.range1_init0_lm01.plumed.dat 10 200

#do this 2x
bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-mean2-cleft-mean-mean2/sgd/flatten_4cv.range10_init0.plumed.dat 100 400
bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-mean2-cleft-mean-mean2/simul/flatten_4cv.range1_init0.plumed.dat 100 200

bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-mean2-cleft-mean-mean2/lm_fixed/flatten_4cv.range1_init0_lm01.plumed.dat 100 200
bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-mean2-cleft-mean-mean2/lm_fixed/flatten_4cv.range1_init0_lm001.plumed.dat 100 200
bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-mean2-cleft-mean-mean2/lm_adaptive/flatten_4cv.range1_init0_lm01.plumed.dat 100 200

bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-cleft-mean/sgd/flatten_4cv.range10_init0.plumed.dat 10 400
bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-cleft-mean/simul/flatten_4cv.range1_init0.plumed.dat 10 200
