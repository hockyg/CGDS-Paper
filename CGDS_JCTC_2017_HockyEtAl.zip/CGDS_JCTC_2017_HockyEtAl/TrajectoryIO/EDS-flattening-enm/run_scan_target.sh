#!/bin/bash
plumedfiles=$(ls -d flatten-dihed-mean-target/meant_0.*/*.plumed.dat |grep -v meant_0.11)
tau=10
for plumedfile in $plumedfiles;do
    echo "bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr $plumedfile $tau 200"
done |parallel -j 8
