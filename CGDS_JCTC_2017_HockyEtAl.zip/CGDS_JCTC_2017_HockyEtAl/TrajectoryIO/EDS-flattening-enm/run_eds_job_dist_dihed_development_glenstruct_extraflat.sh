#!/bin/bash
tprfile=$1
plumedfile=$2
period_in_ps=$3
time_in_ns=$4

source /project/gavoth/glen842/software/gromacs-5.1.2_plumedpinioncleanup/bin/GMXRC
module load cuda/7.5

if [ ! -z $(hostname | grep midway2) ];then
    module unload gcc
    module load lapack
    module load gcc/4.7
fi

gmxexe=gmx_plumed

export PLUMEDDIR=/project/gavoth/glen842/codes/plumed2-plain/src
export PLUMED_KERNEL=$PLUMEDDIR/lib/libplumedKernel.so
export LD_LIBRARY_PATH=$PLUMEDDIR/lib:$LD_LIBRARY_PATH

#single flat monomer NEW VALUES April 17, 2017, for cacb
meant=0.110262
meant2=0.0124479

meand=2.06155
meand2=4.25029

if [ -z "$period_in_ps" ];then
echo "Usage: $0 tprfile plumedfile period_in_ps time_in_ns"
exit
fi

outdir1=$(dirname $plumedfile)

#make sure out dir is not script dir
set -x
if [ $(cd $outdir1;pwd) = $(cd $(dirname $0);pwd) ];then
    echo "plumedfile must not be in the script directory"
    exit
fi

syslabel=$(basename $tprfile .tpr)
joblabel=${syslabel}.$(basename $plumedfile .plumed.dat|cut -f 2 -d '.')
outdir=$outdir1/$joblabel
outprefix=$outdir/${joblabel}.${period_in_ps}ps

timestep=10 #fs
steps=$(echo $time_in_ns*1000000/$timestep |bc)
period=$(echo $period_in_ps*1000/$timestep |bc)
outdir=$(dirname $outprefix)

mkdir -p $outdir

progressfile=$outprefix.progress.txt
# next line returns 0 even if file not found
prevsteps=$(echo "$(cat $progressfile). *1"|bc)
newsteps=$(($prevsteps+$steps))
outprefix_old=${outprefix}.run.$prevsteps
outprefix_new=${outprefix}.run.$newsteps

if [ ! -z "$plumedfile" ];then
    orestart="ORESTARTFILE=$outprefix_new.restart.dat"
    irestartfile=$outprefix_old.restart.dat
    cvfile=$outprefix_new.colvars.dat

    newplumedfile=$outprefix_new.plumed.dat
    if [ -e "$irestartfile" ];then
        irestart="EDSRESTART IRESTARTFILE=$irestartfile"
    else
        irestart=""
    fi

    sed -e "s,_PERIOD_,$period," -e "s,_MEAND_,$meand," -e "s,_MEAND2_,$meand2," -e "s,_MEANT_,$meant," -e "s,_MEANT2_,$meant2," -e "s,_COLVARFILE_,$cvfile," -e "s,_ORESTART_,$orestart," -e "s,_IRESTART_,$irestart," $plumedfile > $newplumedfile

#    sed -e "s,\$INPREF,$outprefix_old," -e "s,\$OUTPREF,$outprefix_new," $plumedfile > $newplumedfile
    plumedstring="-plumed $newplumedfile"
else
    plumedstring=""
fi


if [ "$prevsteps" -gt 0 ];then
    continuestring="-cpi $outprefix_old.cpt"
else
    continuestring=""
fi

mpirun -np 1 $gmxexe mdrun -ntomp 1 -s $tprfile $continuestring -deffnm $outprefix_new -nsteps $steps $plumedstring # 2>&1 > $outprefix_new.stdout.log 

outgro=$outprefix_new.gro
sleep 1
if [ -e "$outgro" ];then
    echo $newsteps > $progressfile
fi

