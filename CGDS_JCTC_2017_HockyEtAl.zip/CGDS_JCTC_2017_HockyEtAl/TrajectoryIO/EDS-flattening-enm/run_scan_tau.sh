#!/bin/bash
#20
#for tau in 5 10 15 25 50 100;do
#for tau in 20;do 
for tau in 1;do 
    echo "bash run_eds_job_dist_dihed_development_glenstruct_extraflat.sh input/gatp-enm-12site_FEStart_eq175ns.tpr flatten-dihed-mean-target/meant_0.11/flatten_mean.range10_init0.plumed.dat $tau 200"
done |parallel -j 8
