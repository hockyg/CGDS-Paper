#!/bin/bash
tprfile=$1
outprefix=$2
time_in_ns=$3
plumedfile=$4
#in kj/mol/nm^2
forceconst=$5
cvfile=$6
gmxexe=$7

#for cacb
#single flat monomer NEW VALUES April 17, 2017, for cacb
meant=0.110262
meant2=0.0124479

meand=2.06155
meand2=4.25029

if [ -z "$gmxexe" ];then
echo "Usage: $0 tprfile outprefix time_in_ns plumedfile forceconst cvfile gmxexe"
exit
fi

timestep=2 #fs
steps=$(echo $time_in_ns*1000000/$timestep |bc)
outdir=$(dirname $outprefix)
mkdir -p $outdir

progressfile=$outprefix.progress.txt
# next line returns 0 even if file not found
prevsteps=$(echo "$(cat $progressfile). *1"|bc)
newsteps=$(($prevsteps+$steps))
outprefix_old=${outprefix}.run.$prevsteps
outprefix_new=${outprefix}.run.$newsteps

if [ ! -z "$plumedfile" ];then
    orestart="ORESTARTFILE=$outprefix_new.restart.dat"
    irestartfile=$outprefix_old.restart.dat
    cvwritefile=$outprefix_new.colvars.dat

    newplumedfile=$outprefix_new.plumed.dat
    if [ -e "$irestartfile" ];then
        irestart="EDSRESTART IRESTARTFILE=$irestartfile"
    else
        irestart=""
    fi

    sed -e "s,_CVFILE_,$cvfile," -e "s/_KAPPAVAL_/$forceconst,$forceconst/" -e "s/_MOMENT1_/$meand,$meant/" -e "s,_COLVARFILE_,$cvwritefile," $plumedfile > $newplumedfile

    plumedstring="-plumed $newplumedfile"
else
    plumedstring=""
fi


if [ "$prevsteps" -gt 0 ];then
    continuestring="-cpi $outprefix_old.cpt"
else
    continuestring=""
fi

#mpirun $gmxexe mdrun -s $tprfile $continuestring -deffnm $outprefix_new -nsteps $steps $plumedstring # 2>&1 > $outprefix_new.stdout.log 
mpirun $gmxexe mdrun -ntomp 1 -s $tprfile $continuestring -deffnm $outprefix_new -nsteps $steps $plumedstring # 2>&1 > $outprefix_new.stdout.log 

outgro=$outprefix_new.gro
sleep 1
if [ -e "$outgro" ];then
    echo $newsteps > $progressfile
fi

