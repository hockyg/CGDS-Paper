#!/bin/bash
tprfile=$1
outprefix=$2
time_in_ns=$3
plumedfile=$4
#in ps
period_in_ps=$5
colvars=$6
mts=$7
gmxexe=$8

if [ ! -z $(hostname | grep midway2) ];then
    module unload gcc
    module load lapack
    module load gcc/4.7
fi

#single flat monomer NEW VALUES April 17, 2017, for cacb
meant=0.110262
meant2=0.0124479

meand=2.06155
meand2=4.25029

if [ -z "$gmxexe" ];then
echo "Usage: $0 tprfile outprefix time_in_ns plumedfile period_in_ps colvarfile mts  gmxexe"
exit
fi

timestep=2 #fs
steps=$(echo $time_in_ns*1000000/$timestep |bc)
period=$(echo $period_in_ps*1000/$timestep |bc)
outdir=$(dirname $outprefix)
mkdir -p $outdir

progressfile=$outprefix.progress.txt
# next line returns 0 even if file not found
prevsteps=$(echo "$(cat $progressfile). *1"|bc)
newsteps=$(($prevsteps+$steps))
outprefix_old=${outprefix}.run.$prevsteps
outprefix_new=${outprefix}.run.$newsteps

if [ ! -z "$plumedfile" ];then
    orestart="ORESTARTFILE=$outprefix_new.restart.dat"
    irestartfile=$outprefix_old.restart.dat
    cvfile=$outprefix_new.colvars.dat

    newplumedfile=$outprefix_new.plumed.dat
    if [ -e "$irestartfile" ];then
        irestart="EDSRESTART IRESTARTFILE=$irestartfile"
    else
        irestart=""
    fi

    sed -e "s,_CVFILE_,$colvars," -e "s,_MTS_,$mts," -e "s,_PERIOD_,$period," -e "s/_MEAND_/$meand/" -e "s/_MEAND2_/$meand2/" -e "s/_MEANT_/$meant/" -e "s/_MEANT2_/$meant2/" -e "s,_COLVARFILE_,$cvfile," -e "s,_DUMPFILE_,$dumpfile," -e "s,_BIASFILE_,$biasfile," -e "s,_ORESTART_,$orestart," -e "s,_IRESTART_,$irestart," $plumedfile > $newplumedfile

    plumedstring="-plumed $newplumedfile"
else
    plumedstring=""
fi


if [ "$prevsteps" -gt 0 ];then
    continuestring="-cpi $outprefix_old.cpt"
else
    continuestring=""
fi

#mpirun $gmxexe mdrun -s $tprfile $continuestring -deffnm $outprefix_new -nsteps $steps $plumedstring # 2>&1 > $outprefix_new.stdout.log 
mpirun $gmxexe mdrun -ntomp 1 -s $tprfile $continuestring -deffnm $outprefix_new -nsteps $steps $plumedstring # 2>&1 > $outprefix_new.stdout.log 

outgro=$outprefix_new.gro
sleep 1
if [ -e "$outgro" ];then
    echo $newsteps > $progressfile
fi

