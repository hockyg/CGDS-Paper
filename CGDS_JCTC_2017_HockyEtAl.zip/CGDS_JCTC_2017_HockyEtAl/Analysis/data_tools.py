def ba(bins):
    return (bins[:-1]+bins[1:])/2

def bootstrap_hist(data_list,nrepeats=300,nbins=20,bins_in=None,density=True):
    import numpy as np
    data_list = np.array(data_list)
    if bins_in is None: 
        bins = nbins
    else:
        bins = bins_in
    hist,bins_total = np.histogram(data_list,bins=bins,density=density)
    nsamples = len(data_list)
    hist_list = []
    for i in range(nrepeats):
        randidx = np.random.randint(0,nsamples,size=nsamples)
        new_data = data_list[randidx]
        hist,bins = np.histogram(new_data,density=density,bins=bins_total)
        hist_list.append(hist)
    hist_array = np.array(hist_list)
    hist_mean = np.mean(hist_array,axis=0)
    hist_std = np.std(hist_array,axis=0)
    return ba(bins_total),hist_mean, hist_std, bins_total
