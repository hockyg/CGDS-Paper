#!/usr/bin/python
import numpy as np

def mdtraj_twelvesite_template(nmonomers,first_monomer=1,actin_seg_template='A%i'):
    monomer_list = range(first_monomer,first_monomer+nmonomers)
    #nuc_seg_template = actin_seg_template.replace('A','N')
    if actin_seg_template.find('%i')>0:
        nuc_seg_template = "N%i"
    else:
        nuc_seg_template = "N"
    string_templates = { 'actin_seg':actin_seg_template, 'nuc_seg':nuc_seg_template }
    bead_string_list = [ 
        "segname %(actin_seg)s and (residue 5 to 33 or residue 80 to 147 or residue 334 to 349)",
        "segname %(actin_seg)s and (residue 34 to 39 or residue 52 to 69)",
        "segname %(actin_seg)s and (residue 148 to 179 or residue 273 to 333)",
        "segname %(actin_seg)s and (residue 180 to 219 or residue 252 to 262)",
        "segname %(actin_seg)s and (residue 40 to 51)",
        "segname %(actin_seg)s and (residue 236 to 251)",
        "segname %(actin_seg)s and (residue 263 to 272)",
        "segname %(actin_seg)s and (residue 350 to 375)",
        "segname %(nuc_seg)s",
        "segname %(actin_seg)s and (residue 1 to 4)",
        "segname %(actin_seg)s and (residue 70 to 79)",
        "segname %(actin_seg)s and (residue 220 to 235)",
    ]
    bead_string_list = [ bead_string%string_templates for bead_string in bead_string_list ]
    if actin_seg_template.find('%i')>-1:
        selection_string_list = [s%i for i in monomer_list for s in bead_string_list ]
    else:
        selection_string_list = [s for i in monomer_list for s in bead_string_list ]
    label_list = ['C%i'%(j+1) for i in monomer_list for j in range(len(bead_string_list)) ]
    resSeq_list = [len(bead_string_list)*i+j+1 for i in range(len(monomer_list)) for j in range(len(bead_string_list)) ]
    segment_id_list = ["A%i"%i for i in monomer_list for s in bead_string_list ]
    chain_list = [i for i in monomer_list for s in bead_string_list ]
    return selection_string_list, label_list, resSeq_list, segment_id_list, chain_list

def mdtraj_get_masses(trj,first_chain_only=False):
    masses = []
    if first_chain_only is True:
        c = trj.top.chains.next()
        for a in c.atoms:
            masses.append(a.element.mass)
    else:
        for a in trj.top.atoms:
            masses.append(a.element.mass)
    return masses

def mdtraj_construct_tuples_resSeqs(trj,resSeqs):
    """ Given a list of res seqs of length l from 2 to 4, construct a numpy array of size (N,l) of atom pairs for these resSeqs. This should apply to N copies of CG monomers for N>=1 """
    assert len(resSeqs)>=2 and len(resSeqs)<=4, "resSeqs must be a list of 2 to 4 residue sequence ids"
    index_lists = []
    for r in resSeqs:
        index_lists.append(trj.top.select("residue %i"%r))
    return np.array(index_lists).transpose()

def mdtraj_construct_tuples_name(trj,atom_names):
    """ Given a list of atom_names of length l from 2 to 4, construct a numpy array of size (N,l) of atom pairs for these atom_names. This should apply to N copies of CG monomers for N>=1 """
    assert len(atom_names)>=2 and len(atom_names)<=4, "atom_names must be a list of 2 to 4 atom_names"
    index_lists = []
    for n in atom_names:
        index_lists.append(trj.top.select("name %s"%n))
    return np.array(index_lists).transpose()

def shift_tuples_by_subunits(tuples_array_in, column, subunits_to_shift, beads_per_subunit, periodicity=None, filament_monomers=None):
    """ Given an (N,l) list of atom pairs, triples or quads, shift one whole column by 'subunits_to_shift' subunits*beads_per_subunit. Specify periodicity as number of total monomers to wrap modulo periodicity*beads_per_subunit """
    tuples_array = tuples_array_in.copy()
    beads_to_shift = subunits_to_shift*beads_per_subunit
    tuples_array[:,column] = tuples_array[:,column]+beads_to_shift
#    if periodicity is not None and type(periodicity)==type(int):
    if periodicity is not None:
        filament_length = periodicity*beads_per_subunit
        needs_shift = np.where(tuples_array[:,column]>=filament_length)
        tuples_array[needs_shift,column] = tuples_array[needs_shift,column] - filament_length

#    if filament_monomers is not None and periodicity is None and type(filament_monomers)==type(int):
    if filament_monomers is not None and periodicity is None:
        filament_length = filament_monomers*beads_per_subunit
        to_keep = np.where(tuples_array[:,column]<filament_length)
        tuples_array = tuples_array[to_keep]

    return tuples_array
